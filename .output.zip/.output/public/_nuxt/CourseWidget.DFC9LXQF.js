import{n as h,i as F,o,c as a,a as e,b as r,w as f,t as i,u as l,F as k,r as b,D as n,g as c,A as x,e as G,d as O}from"./entry.DJi1jURv.js";const Ye=[{id:1,title:"React Front To Back",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:4.8,total:215475},students:616029,authorId:1,courseCategory:"Development",lastUpdated:"Aug 27 2022",courseLanguage:"English",certification:!0,coursePrice:84.99,offerPrice:60,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",progressValue:40,skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-01.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:1,threeStar:6,fourStar:29,fiveStar:63},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:2,title:"PHP Beginner Advanced",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:4.2,total:215475},students:6160,authorId:2,courseCategory:"Web Design",lastUpdated:"Jan 05 2024",courseLanguage:"English",certification:!0,coursePrice:100,offerPrice:80,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",progressValue:65,skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-02.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:1,threeStar:6,fourStar:5,fiveStar:8},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:3,title:"Angular Zero to Mastery",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:5,total:215475},students:6160299,authorId:1,courseCategory:"Graphic Design",lastUpdated:"May 25 2020",courseLanguage:"English",certification:!0,coursePrice:90,offerPrice:40,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",progressValue:90,skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-03.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:1,threeStar:6,fourStar:25,fiveStar:69},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:4,title:"Web Front To Back",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:3.5,total:215475},students:716029,authorId:2,courseCategory:"Development",lastUpdated:"Dec 15 2022",courseLanguage:"English",certification:!0,coursePrice:70,offerPrice:50,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-01.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:6,twoStar:5,threeStar:6,fourStar:65,fiveStar:10},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:5,title:"SQL Beginner Advanced",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:4.1,total:215475},students:456,authorId:1,courseCategory:"Web Design",lastUpdated:"Feb 22 2022",courseLanguage:"English",certification:!0,coursePrice:90,offerPrice:80,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-02.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:1,threeStar:4,fourStar:56,fiveStar:42},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:6,title:"JS Zero to Mastery",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:5,total:215475},students:8152,authorId:2,courseCategory:"Graphic Design",lastUpdated:"Aug 30 2022",courseLanguage:"English",certification:!0,coursePrice:150,offerPrice:100,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-03.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:1,threeStar:6,fourStar:40,fiveStar:20},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:7,title:"The Complete Histudy 2022: From Zero to Expert!",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:2.8,total:215475},students:6584,authorId:1,courseCategory:"Development",lastUpdated:"Mar 07 2021",courseLanguage:"English",certification:!0,coursePrice:56,offerPrice:40,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-04.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:1,twoStar:3,threeStar:6,fourStar:35,fiveStar:55},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:8,title:"The Complete Histudy 2022: From Zero to Expert!",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:3.1,total:215475},students:6987,authorId:1,courseCategory:"Web Design",lastUpdated:"Jul 26 2021",courseLanguage:"English",certification:!0,coursePrice:69,offerPrice:55,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-05.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:5,twoStar:4,threeStar:6,fourStar:5,fiveStar:32},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]},{id:9,title:"The Complete Histudy 2022: From Zero to Expert!",shortDescription:"Master Python by building 100 projects in 100 days. Learn data science, automation, build websites, games and apps!",sellerType:"Bestseller",rating:{average:4.8,total:215475},students:3654,authorId:1,courseCategory:"Graphic Design",lastUpdated:"Apr 09 2022",courseLanguage:"English",certification:!0,coursePrice:99.99,offerPrice:67.99,remainingTime:"3 days left!",courseDuration:"5 Hrs 20 Min",enrolledStudent:"100",lectures:"50",skillLevel:"Basic",passPercentage:95,courseThumbnail:"/images/course/course-online-06.jpg",courseOverview:{whatYouLearn:`<p>
                Are you new to PHP or need a refresher? Then this course will help you get
                all the fundamentals of Procedural PHP, Object Oriented PHP, MYSQLi and
                ending the course by building a CMS system similar to WordPress, Joomla or
                Drupal. Knowing PHP has allowed me to make enough money to stay home and
                make courses like this one for students all over the world. 
            </p>
            <div class="row g-5 mb--30">
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Become an advanced, confident, and
                            modern
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Have an intermediate skill level of
                            Python
                            programming.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Use the numpy library to create and
                            manipulate
                            arrays.
                        </li>
                    </ul>
                </div>
                <div class="col-lg-6">
                    <ul class="rbt-list-style-1">
                        <li><i class="feather-check"></i>Use the Jupyter Notebook
                            Environment.
                            JavaScript developer from scratch.
                        </li>
                        <li><i class="feather-check"></i>Use the pandas module with Python
                            to create and
                            structure data.
                        </li>
                        <li><i class="feather-check"></i>Have a portfolio of various data
                            analysis
                            projects.
                        </li>
                        <li><i class="feather-check"></i>Create data visualizations using
                            matplotlib and
                            the seaborn.
                        </li>
                    </ul>
                </div>
            </div>
            <p>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Omnis, aliquam
                voluptas laudantium incidunt architecto nam excepturi provident rem laborum
                repellendus placeat neque aut doloremque ut ullam, veritatis nesciunt iusto
                officia alias, non est vitae. Eius repudiandae optio quam alias aperiam nemo
                nam tempora, dignissimos dicta excepturi ea quo ipsum omnis maiores
                perferendis commodi voluptatum facere vel vero. Praesentium quisquam iure
                veritatis, perferendis adipisci sequi blanditiis quidem porro eligendi
                fugiat facilis inventore amet delectus expedita deserunt ut molestiae modi
                laudantium, quia tenetur animi natus ea. Molestiae molestias ducimus
                pariatur et consectetur. Error vero, eum soluta delectus necessitatibus
                eligendi numquam hic at?
            </p>`},courseContent:[{title:"Intro to Course and Histudy",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!0},{title:"Watch Before Start",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"0.5 min",unlocked:!0},{title:"Course Intro",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Fundamentals",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"You can develop skill and setup",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"15 Things To Know About Education?",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]},{title:"Course Description",lectures:[{title:"Course Intro",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Why You Should Not Go To Education.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1},{title:"Ten Factors That Affect Education's Longevity.",type:"video",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",duration:"30 min",unlocked:!1},{title:"Read Before You Start",type:"document",link:"https://www.youtube.com/watch?v=xFOG_9Y883c",unlocked:!1}]}],courseRequirements:["Become an advanced, confident, and modern JavaScript developer from scratch.","Have an intermediate skill level of Python programming.","Have a portfolio of various data analysis projects.","Use the numpy library to create and manipulate arrays."],courseDescriptions:["Use the Jupyter Notebook Environment. JavaScript developer from scratch.","Use the pandas module with Python to create and structure data.","Have a portfolio of various data analysis projects.","Create data visualizations using matplotlib and the seaborn."],instructorId:1,socialLinks:[{facebook:"https://www.facebook.com/"},{twitter:"https://twitter.com/"},{instagram:"https://www.instagram.com/"},{linkedin:"https://www.linkedin.com/"}],reviews:{oneStar:4,twoStar:9,threeStar:44,fourStar:36,fiveStar:8},featuredReviews:[1,2,3,4,5],instructorTopCourses:[2,3],relatedCourses:[4,5,6]}],S={class:"rbt-card variation-01 rbt-hover"},P={class:"rbt-card-img"},T={class:"rbt-badge-3 bg-white"},B=e("span",null,"Off",-1),C={class:"rbt-card-body"},E={key:0,class:"rbt-card-top"},R={class:"rbt-review"},H={class:"rating"},q={class:"rating-count"},L=e("div",{class:"rbt-bookmark-btn"},[e("a",{class:"rbt-round-btn",title:"Bookmark",href:"#"},[e("i",{class:"feather-bookmark"})])],-1),I={key:1,class:"rbt-card-title"},J={class:"rbt-meta"},j=e("i",{class:"feather-book"},null,-1),A=e("i",{class:"feather-users"},null,-1),U={key:2,class:"rbt-progress-style-1 mb--20 mt--10"},D={class:"single-progress"},W=e("h6",{class:"rbt-title-style-2 mb--10"},"Complete",-1),N={key:0,class:"progress"},M=e("div",{class:"progress-bar wow fadeInLeft bar-color-success","data-wow-duration":"0.5s","data-wow-delay":".3s",role:"progressbar",style:{width:"100%"},"aria-valuenow":100,"aria-valuemin":0,"aria-valuemax":100},null,-1),z=e("span",{class:"rbt-title-style-2 progress-number"}," 100% ",-1),K=[M,z],Q={key:1,class:"progress"},V=["aria-valuenow"],$={class:"rbt-title-style-2 progress-number"},Z={key:3,class:"rbt-card-bottom"},X=e("a",{class:"rbt-btn btn-sm bg-primary-opacity w-100 text-center",href:"#"}," Download Certificate ",-1),ee=[X],te={key:4,class:"rbt-card-title"},oe={href:"#"},ae={key:5,class:"rbt-card-text"},ie={key:6,class:"rbt-author-meta mb--20"},ne={class:"rbt-avater"},se={href:"#"},ce=e("div",{class:"rbt-author-info"},[c(" By "),e("a",{href:"#"},"Patrick"),c(" In"+i(" ")+" "),e("a",{href:"#"},"Languages")],-1),ue={key:7,class:"rbt-review"},le={class:"rating"},re={class:"rating-count"},de={key:8,class:"rbt-card-bottom"},me={class:"rbt-price"},we={class:"current-price"},he={class:"off-price"},pe={key:0,class:"rbt-btn-link left-icon",href:"#"},ve=e("i",{class:"feather-edit"},null,-1),ye={key:1,class:"rbt-btn-link",href:"#"},fe=e("i",{class:"feather-arrow-right"},null,-1),ge={__name:"CourseWidget",props:["data","courseStyle","showDescription","showAuthor","isProgress","isCompleted","isEdit"],setup(t){const s=t,p=h(""),d=h(""),m=h(""),Y=()=>{let u=s.data.coursePrice*((100-s.data.offerPrice)/100);p.value=u.toFixed(0)},g=()=>{let u=s.data.reviews.oneStar+s.data.reviews.twoStar+s.data.reviews.threeStar+s.data.reviews.fourStar+s.data.reviews.fiveStar;d.value=u},_=()=>{let u=s.data.rating.average;m.value=u.toFixed(0)};return F(()=>{Y(),g(),_()}),(u,ke)=>{const v=G,y=O;return o(),a("div",S,[e("div",P,[r(y,{to:`/course-details/${t.data.id}`},{default:f(()=>[r(v,{src:t.data.courseThumbnail,alt:t.data.title},null,8,["src","alt"]),e("div",T,[e("span",null,i(`-${l(p)}%`),1),B])]),_:1},8,["to"])]),e("div",C,[t.courseStyle==="two"?(o(),a("div",E,[e("div",R,[e("div",H,[(o(!0),a(k,null,b(l(m),w=>(o(),a("i",{key:w,class:"fas fa-star"}))),128))]),e("span",q,"("+i(l(d))+" Reviews)",1)]),L])):n("",!0),t.courseStyle==="two"?(o(),a("h4",I,[r(y,{to:`/course-details/${t.data.id}`},{default:f(()=>[c(i(t.data.title),1)]),_:1},8,["to"])])):n("",!0),e("ul",J,[e("li",null,[j,c(" "+i(t.data.lectures)+" Lessons ",1)]),e("li",null,[A,c(" "+i(t.data.enrolledStudent)+" Students ",1)])]),t.isProgress?(o(),a("div",U,[e("div",D,[W,t.isCompleted?(o(),a("div",N,K)):(o(),a("div",Q,[e("div",{class:"progress-bar wow fadeInLeft bar-color-success","data-wow-duration":"0.5s","data-wow-delay":".3s",role:"progressbar",style:x({width:`${t.data.progressValue}%`}),"aria-valuenow":t.data.progressValue,"aria-valuemin":0,"aria-valuemax":100},null,12,V),e("span",$,i(t.data.progressValue)+"% ",1)]))])])):n("",!0),t.isProgress?(o(),a("div",Z,ee)):n("",!0),t.courseStyle==="one"?(o(),a("h4",te,[e("a",oe,i(t.data.title),1)])):n("",!0),t.showDescription?(o(),a("p",ae,i(t.data.shortDescription),1)):n("",!0),t.courseStyle==="two"&&t.showAuthor?(o(),a("div",ie,[e("div",ne,[e("a",se,[r(v,{src:"/images/client/avater-01.png",alt:"Sophia Jaymes"})])]),ce])):n("",!0),t.courseStyle==="one"?(o(),a("div",ue,[e("div",le,[(o(!0),a(k,null,b(l(m),w=>(o(),a("i",{key:w,class:"fas fa-star"}))),128))]),e("span",re," ("+i(l(d))+" Reviews)",1)])):n("",!0),t.isProgress?n("",!0):(o(),a("div",de,[e("div",me,[e("span",we,"$"+i(t.data.offerPrice),1),e("span",he,"$"+i(t.data.coursePrice),1)]),t.isEdit?(o(),a("a",pe,[ve,c(" Edit ")])):(o(),a("a",ye,[c(" Learn More "),fe]))]))])])}}};export{Ye as C,ge as _};
