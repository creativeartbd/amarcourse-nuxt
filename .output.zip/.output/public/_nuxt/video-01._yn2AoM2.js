import"./entry.DJi1jURv.js";const o=""+globalThis.__publicAssetsURL("images/others/video-01.jpg");export{o as _};
